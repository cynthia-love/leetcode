# -*- coddng: utf-8 -*-
# Author: Cynthia

lines = "这里是hellopy包opts子包const模块中的lines变量"