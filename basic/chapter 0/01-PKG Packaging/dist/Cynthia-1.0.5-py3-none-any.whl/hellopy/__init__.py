# -*- coding: utf-8 -*-
# Author: Cynthia

# import os
# import sys
#
# sys.path.append(os.path.dirname(os.path.abspath(__file__)))
# 包内部互相调用不要采用相对导入, 那么这里就没必要添加sys.path了

print("package hellopy imported!!!")