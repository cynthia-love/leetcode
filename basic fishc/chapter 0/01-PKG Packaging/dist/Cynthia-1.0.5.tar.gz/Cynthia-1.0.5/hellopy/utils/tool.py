# -*- coding: utf-8 -*-

# Author: Cynthia

def f():
    print("这里是hellopy包utils子包tool模块中的f函数")

if __name__ == '__main__':
    f()